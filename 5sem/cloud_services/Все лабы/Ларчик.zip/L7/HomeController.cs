﻿using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Quees.Models;
using Queue_Storage_In_Azure;

namespace Quees.Controllers
{
    public class HomeController : Controller
    {
        public HomeController() { }

        public ActionResult Index(string message)
        {
            ViewData["result"] = message;
            return View();
        }

        [HttpPost]
        public ActionResult AddMessage(string message)
        {
            QueueOperations qo = new QueueOperations();

            qo.AddMessageInQueue(message);
            return RedirectToAction("Index", new { message = "Текст добавлен" });
        }

        [HttpPost]
        public ActionResult RetrieveMessage()
        {
            try
            {
                QueueOperations qo = new QueueOperations();
                return RedirectToAction("Index", new { message = qo.RetrieveMessageFormQueue().AsString });
            }
            catch(NullReferenceException)
            {
                return RedirectToAction("Index", new { message = "В очереди нет сообщений" });
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
