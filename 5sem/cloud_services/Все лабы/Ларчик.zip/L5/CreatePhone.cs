﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebApplication.ViewModels
{
    public class CreatePhone
    {
        public SelectList Manufacturers { get; set; }
        public SelectList Countries { get; set; }
    }
}
