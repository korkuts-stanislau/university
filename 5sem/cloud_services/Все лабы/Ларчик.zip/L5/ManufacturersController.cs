﻿using CosmosTableSamples;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace WebApplication.Controllers
{
    public class ManufacturersController : Controller
    {
        private readonly StorageOperations _so;
        private readonly EntityOperations _eo;

        public ManufacturersController()
        {
            _so = new StorageOperations();
            _eo = new EntityOperations();
        }

        public async Task<ActionResult> Index()
        {
            var manufacturersTable = await _so.CreateTableAsync("manufacturers");
            var manufacturers = _eo.GetManufacturers(manufacturersTable);
            return View(manufacturers);
        }

        public async Task<ActionResult> Delete(int id)
        {
            var phonesTable = await _so.CreateTableAsync("phones");
            var manufacturersTable = await _so.CreateTableAsync("manufacturers");
            await _eo.CascadeDeleteManufacturer(phonesTable, manufacturersTable, new CosmosTableSamples.Models.Manufacturer(id)
            {
                ETag = "*"
            });
            return RedirectToAction(nameof(Index));
        }
    }
}
