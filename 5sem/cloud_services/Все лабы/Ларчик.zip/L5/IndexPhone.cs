﻿using System.Collections.Generic;

namespace WebApplication.ViewModels
{
    public class IndexPhone
    {
        public List<CosmosTableSamples.Models.Phone> Phones { get; set; }
        public Dictionary<string, string> Countries { get; set; }
        public Dictionary<string, string> Manufacturers { get; set; }
    }
}
