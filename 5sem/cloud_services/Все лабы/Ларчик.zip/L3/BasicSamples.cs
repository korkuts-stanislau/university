﻿using System;
using System.Linq;

namespace CosmosTableSamples
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Microsoft.Azure.Cosmos.Table;
    using Model;

    class BasicSamples
    {
        public async Task RunSamples()
        {
            string tableName = "HeavyIndusty";

            // Create or reference an existing table
            CloudTable table = await Common.CreateTableAsync(tableName);

            try
            {
                // Demonstrate basic CRUD functionality 
                await BasicDataOperationsAsync(table);
            }
            finally
            {
                // Delete the table
                // await table.DeleteIfExistsAsync();
            }
        }

        private static async Task BasicDataOperationsAsync(CloudTable table)
        {
            List<Prom> proms = new List<Prom>();
            proms.Add(new Prom("1", "1")
            {
                PromType = "Станки",
                Unit = "тыс. шт.",
                Year1913 = 1.5,
                Year1928 = 2.0,
                Year1940 = 58.4,
                Year1958 = 138
            });

            proms.Add(new Prom("1", "2")
            {
                PromType = "Турбины",
                Unit = "тыс. кВт.",
                Year1913 = 5.9,
                Year1928 = 44.1,
                Year1940 = 1179.0,
                Year1958 = 6031
            });

            proms.Add(new Prom("1", "3")
            {
                PromType = "Экскаваторы",
                Unit = "шт.",
                Year1913 = 0,
                Year1928 = 0,
                Year1940 = 274,
                Year1958 = 10105
            });

            proms.Add(new Prom("1", "4")
            {
                PromType = "Цемент",
                Unit = "млн. тонн",
                Year1913 = 1.5,
                Year1928 = 1.8,
                Year1940 = 5.7,
                Year1958 = 33.1
            });

            proms.Add(new Prom("1", "5")
            {
                PromType = "Автомобили",
                Unit = "тыс. шт.",
                Year1913 = 0,
                Year1928 = 0.84,
                Year1940 = 145.4,
                Year1958 = 511
            });

            proms.Add(new Prom("1", "6")
            {
                PromType = "Тракторы",
                Unit = "тыс. шт.",
                Year1913 = 0,
                Year1928 = 1.3,
                Year1940 = 31.6,
                Year1958 = 219.7
            });

            foreach (Prom prom in proms)
            {
                await SamplesUtils.InsertOrMergeEntityAsync(table, prom);
            }

            // Выполнение пункта а
            // Производство какой продукции тяжелой промышленности в 1928г.
            // было минимальным? [вид продукции, объем ее производства в 1928г.,
            // единица измерения];
            double min1928 = double.MaxValue;
            Prom minProm = null;

            Console.WriteLine("1:");
            for (int i = 1; i < 7; i++)
            {
                var pr = await SamplesUtils.RetrieveEntityUsingPointQueryAsync(table, "1", i.ToString());
                if (pr.Year1928 < min1928)
                {
                    min1928 = pr.Year1928;
                    minProm = pr;
                }
            }
            Console.WriteLine($"{minProm.PromType}, {minProm.Year1928} {minProm.Unit}");

            // Выполнение пункта б
            // Производство каких видов продукции тяжелой промышленности в
            // 1958г.было меньше 300 тыс.штук?[вид продукции, объем ее производства в
            // 1958г., единицы измерения.].
            Console.WriteLine("2:");
            for (int i = 1; i < 7; i++)
            {
                var pr = await SamplesUtils.RetrieveEntityUsingPointQueryAsync(table, "1", i.ToString());
                if (pr.Year1958 < 300)
                {
                    Console.WriteLine($"{pr.PromType}, {pr.Year1958} {pr.Unit}");
                }
            }
        }
    }
}
