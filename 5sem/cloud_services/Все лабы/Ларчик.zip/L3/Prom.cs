﻿using Microsoft.Azure.Cosmos.Table;

namespace CosmosTableSamples.Model
{
    class Prom : TableEntity
    {
        public Prom() { }

        public Prom(string partition, string index)
        {
            PartitionKey = partition;
            RowKey = index;
        }

        public string PromType { get; set; }
        public string Unit { get; set; }
        public double Year1913 { get; set; }
        public double Year1928 { get; set; }
        public double Year1940 { get; set; }
        public double Year1958 { get; set; }
    }

}
