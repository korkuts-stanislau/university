﻿using Microsoft.Azure.Cosmos.Table;
using System.Threading.Tasks;

namespace CosmosTableSamples
{
    public class StorageOperations
    {
        public async Task<CloudTable> CreateTableAsync(string tableName)
        {
            return await Common.CreateTableAsync(tableName);
        }
    }
}
