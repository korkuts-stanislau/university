﻿using System;

namespace CosmosTableSamples
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Microsoft.Azure.Cosmos.Table;
    using Model;

    class BasicSamples
    {
        public async Task RunSamples()
        {
            string tableName = "ManufactureOfIronAndSteel";

            // Create or reference an existing table
            CloudTable table = await Common.CreateTableAsync(tableName);

            try
            {
                // Demonstrate basic CRUD functionality 
                await BasicDataOperationsAsync(table);
            }
            finally
            {
                // Delete the table
                // await table.DeleteIfExistsAsync();
            }
        }

        private static async Task BasicDataOperationsAsync(CloudTable table)
        {
            List<Manufacture> manufactures = new List<Manufacture>();
            manufactures.Add(new Manufacture("1", "1")
            {
                Country = "Китай",
                Iron1938 = 945,
                Iron1958 = 13690,
                Steel1938 = 488,
                Steel1958 = 11080
            });

            manufactures.Add(new Manufacture("1", "2")
            {
                Country = "Чехославакия",
                Iron1938 = 1675,
                Iron1958 = 3774,
                Steel1938 = 2118,
                Steel1958 = 5510
            });

            manufactures.Add(new Manufacture("1", "3")
            {
                Country = "Польша",
                Iron1938 = 880,
                Iron1958 = 3864,
                Steel1938 = 1440,
                Steel1958 = 5631
            });

            manufactures.Add(new Manufacture("1", "4")
            {
                Country = "Венгрия",
                Iron1938 = 335,
                Iron1958 = 1082,
                Steel1938 = 647,
                Steel1958 = 1627
            });

            manufactures.Add(new Manufacture("1", "5")
            {
                Country = "Румыния",
                Iron1938 = 132,
                Iron1958 = 737,
                Steel1938 = 284,
                Steel1958 = 934
            });

            foreach (Manufacture manuf in manufactures)
            {
                await SamplesUtils.InsertOrMergeEntityAsync(table, manuf);
            }

            // Выполнение пункта а
            // В какой стране в 1958г. произвели меньше всего чугуна?
            // [страна, обьем производства чугуна в 1958г.]
            int minIron1958 = int.MaxValue;
            Manufacture minManuf = null;

            for (int i = 1; i < 6; i++)
            {
                var man = await SamplesUtils.RetrieveEntityUsingPointQueryAsync(table, "1", i.ToString());
                if (man.Iron1958 < minIron1958)
                {
                    minIron1958 = man.Iron1958;
                    minManuf = man;
                }
            }
            Console.WriteLine($"В какой стране в 1958г. произвели меньше всего чугуна?\n{minManuf.Country}, {minManuf.Iron1958}");

            // Выполнение пункта б
            // В каких странах производство стали в 1938г. не превысило 900 тыс.т.?
            // [страна, обьем производства стали в 1938г.]
            for (int i = 1; i < 6; i++)
            {
                var man = await SamplesUtils.RetrieveEntityUsingPointQueryAsync(table, "1", i.ToString());
                if (man.Steel1938 < 900)
                {
                    Console.WriteLine($"В каких странах производство стали в 1938г. не превысило 900 тыс.т.?\n{man.Country}, {man.Steel1938}");
                }
            }
        }
    }
}
