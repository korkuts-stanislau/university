﻿using Microsoft.Azure.Cosmos.Table;

namespace CosmosTableSamples.Model
{
    class Manufacture : TableEntity
    {
        public Manufacture() { }

        public Manufacture(string partition, string index)
        {
            PartitionKey = partition;
            RowKey = index;
        }

        public string Country { get; set; }
        public int Iron1938 { get; set; }
        public int Iron1958 { get; set; }
        public int Steel1938 { get; set; }
        public int Steel1958 { get; set; }
    }
}
