using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage;
using System.Threading.Tasks;
using CosmosTableSamples;
using CosmosTableSamples.Model;

namespace FunctionApp
{
    public static class Function
    {
        [FunctionName("Delete")]
        public static async Task RunAsync([TimerTrigger("*/5 * * * * *")] TimerInfo myTimer, ILogger log)
        {
            EntityOperations eo = new EntityOperations();
            StorageOperations so = new StorageOperations();

            // ���������� ������� �������
            // var componentsTable = await so.CreateTableAsync("ComputerComponents");
            // int size = 15;
            // Random rand = new Random();

            // for (int i = 0; i < size; i++)
            // {
            //     var component = new ComputerComponent(i)
            //     {
            //         Name = $"ComputerComponent{i + 1}",
            //         Characteristics = $"Characteristics{i + 1}",
            //         ManufactureID = i,
            //         Price = rand.Next(1000, 10000) + Math.Round(rand.NextDouble(), 2)
            //     };

            //     await eo.InsertOrMergeComputerComponentAsync(componentsTable, component);
            // }

            // ���������� �������� ������� �� �������
            try
            {
                var componentsTable = await so.CreateTableAsync("ComputerComponents");
                var components = eo.GetComputerComponents(componentsTable);

                await eo.DeleteComputerComponentAsync(componentsTable, components[components.Count - 1]);
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }
    }
}
