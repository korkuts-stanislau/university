﻿using CosmosTableSamples.Model;
using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CosmosTableSamples
{
    public class EntityOperations
    {
        public static async Task<ComputerComponent> GetComputerComponentAsync(CloudTable table, int id)
        {
            string partitionKey = "1";
            try
            {
                TableOperation retrieveOperation = TableOperation.Retrieve<ComputerComponent>(partitionKey, id.ToString());
                TableResult result = await table.ExecuteAsync(retrieveOperation);
                ComputerComponent component = result.Result as ComputerComponent;
                return component;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public List<ComputerComponent> GetComputerComponents(CloudTable table)
        {
            TableQuery<ComputerComponent> componentsQuery = new TableQuery<ComputerComponent>();
            List<ComputerComponent> components = new List<ComputerComponent>();
            foreach (ComputerComponent component in table.ExecuteQuery(componentsQuery))
            {
                components.Add(component);
            }
            return components;
        }

        public async Task<ComputerComponent> InsertOrMergeComputerComponentAsync(CloudTable table, ComputerComponent component)
        {
            try
            {
                TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(component);
                TableResult result = await table.ExecuteAsync(insertOrMergeOperation);
                ComputerComponent insertedComponent = result.Result as ComputerComponent;

                return insertedComponent;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task<ComputerComponent> DeleteComputerComponentAsync(CloudTable table, ComputerComponent component)
        {
            try
            {
                TableOperation deleteOperation = TableOperation.Delete(component);
                TableResult result = await table.ExecuteAsync(deleteOperation);
                ComputerComponent deletedComponent = result.Result as ComputerComponent;

                return deletedComponent;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        // таблица Manufacture
        public static async Task<Manufacture> GetManufactureAsync(CloudTable table, int id)
        {
            string partitionKey = "1";
            try
            {
                TableOperation retrieveOperation = TableOperation.Retrieve<Manufacture>(partitionKey, id.ToString());
                TableResult result = await table.ExecuteAsync(retrieveOperation);
                Manufacture manufacture = result.Result as Manufacture;
                return manufacture;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public List<Manufacture> GetManufactures(CloudTable table)
        {
            TableQuery<Manufacture> manufacturesQuery = new TableQuery<Manufacture>();
            List<Manufacture> manufactures = new List<Manufacture>();
            foreach (Manufacture manufacture in table.ExecuteQuery(manufacturesQuery))
            {
                manufactures.Add(manufacture);
            }
            return manufactures;
        }

        public async Task<Manufacture> InsertOrMergeManufactureAsync(CloudTable table, Manufacture manufacture)
        {
            try
            {
                TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(manufacture);
                TableResult result = await table.ExecuteAsync(insertOrMergeOperation);
                Manufacture insertedManufacture = result.Result as Manufacture;

                return insertedManufacture;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task<Manufacture> DeleteManufactureAsync(CloudTable table, Manufacture manufacture)
        {
            try
            {
                TableOperation deleteOperation = TableOperation.Delete(manufacture);
                TableResult result = await table.ExecuteAsync(deleteOperation);
                Manufacture deletedManufacture = result.Result as Manufacture;

                return deletedManufacture;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task CascadeDeleteManufacture(CloudTable computerComponentsTable, CloudTable manufacturesTable, Manufacture manufacture)
        {
            try
            {
                var components = GetComputerComponents(computerComponentsTable);
                foreach (ComputerComponent component in components)
                {
                    if (component.ManufactureID == int.Parse(manufacture.RowKey))
                    {
                        await DeleteComputerComponentAsync(computerComponentsTable, component);
                    }
                }
                await DeleteManufactureAsync(manufacturesTable, manufacture);
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        // таблица Country
        public static async Task<Country> GetCountryAsync(CloudTable table, int id)
        {
            string partitionKey = "1";
            try
            {
                TableOperation retrieveOperation = TableOperation.Retrieve<Country>(partitionKey, id.ToString());
                TableResult result = await table.ExecuteAsync(retrieveOperation);
                Country country = result.Result as Country;
                return country;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public List<Country> GetCountries(CloudTable table)
        {
            TableQuery<Country> countriesQuery = new TableQuery<Country>();
            List<Country> countries = new List<Country>();
            foreach (Country country in table.ExecuteQuery(countriesQuery))
            {
                countries.Add(country);
            }
            return countries;
        }

        public async Task<Country> InsertOrMergeCountryAsync(CloudTable table, Country country)
        {
            try
            {
                TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(country);
                TableResult result = await table.ExecuteAsync(insertOrMergeOperation);
                Country insertedCountry = result.Result as Country;

                return insertedCountry;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task<Country> DeleteCountryAsync(CloudTable table, Country country)
        {
            try
            {
                TableOperation deleteOperation = TableOperation.Delete(country);
                TableResult result = await table.ExecuteAsync(deleteOperation);
                Country deletedCountry = result.Result as Country;

                return deletedCountry;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task CascadeDeleteCountry(CloudTable manufacturesTable, CloudTable countriesTable, Country country)
        {
            try
            {
                var manufactures = GetManufactures(manufacturesTable);
                foreach (Manufacture manufacture in manufactures)
                {
                    if (manufacture.CountryID == int.Parse(country.RowKey))
                    {
                        await DeleteManufactureAsync(manufacturesTable, manufacture);
                    }
                }
                await DeleteCountryAsync(countriesTable, country);
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }
    }
}
