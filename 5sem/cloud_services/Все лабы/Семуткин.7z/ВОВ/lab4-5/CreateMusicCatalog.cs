﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebApplication.ViewModels
{
    public class CreateMusicCatalog
    {
        public SelectList Countries { get; set; }
        public SelectList Genres { get; set; }
        public SelectList Styles { get; set; }
    }
}
