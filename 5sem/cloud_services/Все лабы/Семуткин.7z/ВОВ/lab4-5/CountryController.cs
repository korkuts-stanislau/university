﻿using CosmosTableSamples;
using Microsoft.AspNetCore.Mvc;
using CosmosTableSamples.Model;
using System.Threading.Tasks;
using System.Linq;

namespace WebApplication.Controllers
{
    public class CountryController : Controller
    {
        private readonly StorageOperations _so;
        private readonly EntityOperations _eo;

        public CountryController()
        {
            _so = new StorageOperations();
            _eo = new EntityOperations();
        }

        public async Task<ActionResult> Index()
        {
            var countriesTable = await _so.CreateTableAsync("Countries");
            var countries = _eo.GetCountries(countriesTable);

            return View(countries);
        }

        public async Task<ActionResult> Create()
        {
            var countriesTable = await _so.CreateTableAsync("Countries");
            var countries = _eo.GetCountries(countriesTable);

            return View(countries);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(string countryName)
        {
            try
            {
                var countriesTable = await _so.CreateTableAsync("Countries");
                int maxID = _eo.GetCountries(countriesTable)
                    .Select(c => int.Parse(c.RowKey)).Max();

                Country country = new Country(maxID + 1)
                {
                    CountryName = countryName
                };
                await _eo.InsertOrMergeCountryAsync(countriesTable, country);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                var countriesTable = await _so.CreateTableAsync("Countries");
                var countries = _eo.GetCountries(countriesTable);

                return View(countries);
            }
        }

        public async Task<ActionResult> Edit(int id)
        {
            var countriesTable = await _so.CreateTableAsync("Countries");
            var country = _eo.GetCountries(countriesTable)
                .FirstOrDefault(c => int.Parse(c.RowKey) == id);
            ViewBag.Country = country;

            return View(country);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, string countryName)
        {
            try
            {
                Country country = new Country(id)
                {
                    CountryName = countryName
                };

                var countriesTable = await _so.CreateTableAsync("Countries");
                await _eo.InsertOrMergeCountryAsync(countriesTable, country);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                var countriesTable = await _so.CreateTableAsync("Countries");
                var country = _eo.GetCountries(countriesTable)
                    .FirstOrDefault(c => int.Parse(c.RowKey) == id);
                ViewBag.Country = country;

                return View(country);
            }
        }

        public async Task<ActionResult> Delete(int id)
        {
            var catalogTable = await _so.CreateTableAsync("MusicCatalog");
            var countriesTable = await _so.CreateTableAsync("Countries");

            await _eo.CascadeDeleteCountry(catalogTable, countriesTable, new Country(id)
            {
                ETag = "*"
            });

            return RedirectToAction(nameof(Index));
        }
    }
}
