﻿using Microsoft.Azure.Cosmos.Table;
using System;

namespace CosmosTableSamples.Model
{
    public class MusicCatalog : TableEntity
    {
        public string MusicName { get; set; }
        public string Format { get; set; }
        public int CountryID { get; set; }
        public DateTime ReleaseDate { get; set; }
        public int GenreID { get; set; }
        public int StyleID { get; set; }
        public string Description { get; set; }

        public MusicCatalog(int id)
        {
            PartitionKey = "1";
            RowKey = id.ToString();
        }

        public MusicCatalog() { }
    }
}
