﻿using CosmosTableSamples;
using CosmosTableSamples.Model;
using System.Threading.Tasks;
using System;

namespace WebApplication.Data
{
    public class StorageInitializer
    {
        StorageOperations _so;
        EntityOperations _eo;

        public StorageInitializer()
        {
            _so = new StorageOperations();
            _eo = new EntityOperations();
        }

        public async Task Initialize()
        {
            var genres = await _so.CreateTableAsync("Genres");
            var styles = await _so.CreateTableAsync("Styles");
            var countries = await _so.CreateTableAsync("Countries");
            var musicCatalog = await _so.CreateTableAsync("MusicCatalog");

            // константа для количества записей на странице
            const int pageSize = 10;

            // добавление записей в таблицу Genre
            for (int i = 0; i < pageSize; i++)
            {
                var genre = new Genre(i)
                {
                    GenreName = $"Genre{i + 1}"
                };

                await _eo.InsertOrMergeGenreAsync(genres, genre);
            }

            // добавление записей в таблицу Style
            for (int i = 0; i < pageSize; i++)
            {
                var style = new Style(i)
                {
                    StyleName = $"Style{i + 1}"
                };

                await _eo.InsertOrMergeStyleAsync(styles, style);
            }

            // добавление записей в таблицу Country
            for (int i = 0; i < pageSize; i++)
            {
                var country = new Country(i)
                {
                    CountryName = $"Country{i + 1}"
                };

                await _eo.InsertOrMergeCountryAsync(countries, country);
            }

            // добавление записей в таблицу MusicCatalog
            for (int i = 0; i < pageSize; i++)
            {
                var catalog = new MusicCatalog(i)
                {
                    MusicName = $"Music{i + 1}",
                    Format = $"Format{i + 1}",
                    CountryID = i,
                    ReleaseDate = RandomDate(),
                    GenreID = i,
                    StyleID = i,
                    Description = $"Description{i + 1}"
                };

                await _eo.InsertOrMergeMusicCatalogAsync(musicCatalog, catalog);
            }

            // функция для рандомной даты
            static DateTime RandomDate()
            {
                Random random = new Random();
                DateTime startDate = new DateTime(1950, 1, 1);
                int range = (DateTime.Today - startDate).Days;

                return startDate.AddDays(random.Next(range));
            }
        }
    }
}
