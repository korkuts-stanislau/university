﻿using Microsoft.Azure.Cosmos.Table;

namespace CosmosTableSamples.Model
{
    public class Style : TableEntity
    {
        public string StyleName { get; set; }

        public Style(int id)
        {
            PartitionKey = "1";
            RowKey = id.ToString();
        }

        public Style() { }
    }
}
