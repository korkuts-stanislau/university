﻿using CosmosTableSamples.Model;
using System.Collections.Generic;

namespace WebApplication.ViewModels
{
    public class IndexMusicCatalog
    {
        public List<MusicCatalog> MusicCatalogs { get; set; }
        public Dictionary<string, string> Countries { get; set; }
        public Dictionary<string, string> Genres { get; set; }
        public Dictionary<string, string> Styles { get; set; }
    }
}
