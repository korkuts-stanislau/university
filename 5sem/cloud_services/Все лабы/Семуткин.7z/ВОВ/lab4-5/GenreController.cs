﻿using CosmosTableSamples;
using CosmosTableSamples.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.Controllers
{
    public class GenreController : Controller
    {
        private readonly StorageOperations _so;
        private readonly EntityOperations _eo;

        public GenreController()
        {
            _so = new StorageOperations();
            _eo = new EntityOperations();
        }

        public async Task<ActionResult> Index()
        {
            var genresTable = await _so.CreateTableAsync("Genres");
            var genres = _eo.GetGenres(genresTable);

            return View(genres);
        }

        public async Task<ActionResult> Create()
        {
            var genresTable = await _so.CreateTableAsync("Genres");
            var genres = _eo.GetGenres(genresTable);

            return View(genres);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(string genreName)
        {
            try
            {
                var genresTable = await _so.CreateTableAsync("Genres");
                int maxID = _eo.GetGenres(genresTable)
                    .Select(g => int.Parse(g.RowKey)).Max();

                Genre genre = new Genre(maxID + 1)
                {
                    GenreName = genreName
                };
                await _eo.InsertOrMergeGenreAsync(genresTable, genre);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                var genresTable = await _so.CreateTableAsync("Genres");
                var genres = _eo.GetStyles(genresTable);

                return View(genres);
            }
        }

        public async Task<ActionResult> Edit(int id)
        {
            var genresTable = await _so.CreateTableAsync("Genres");
            var genre = _eo.GetGenres(genresTable)
                .FirstOrDefault(g => int.Parse(g.RowKey) == id);
            ViewBag.Genre = genre;

            return View(genre);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, string genreName)
        {
            try
            {
                Genre genre = new Genre(id)
                {
                    GenreName = genreName
                };

                var genresTable = await _so.CreateTableAsync("Genres");
                await _eo.InsertOrMergeGenreAsync(genresTable, genre);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                var genresTable = await _so.CreateTableAsync("Genres");
                var genre = _eo.GetGenres(genresTable)
                    .FirstOrDefault(g => int.Parse(g.RowKey) == id);
                ViewBag.Genre = genre;

                return View(genre);
            }
        }

        public async Task<ActionResult> Delete(int id)
        {
            var catalogTable = await _so.CreateTableAsync("MusicCatalog");
            var genresTable = await _so.CreateTableAsync("Genres");

            await _eo.CascadeDeleteGenre(catalogTable, genresTable, new Genre(id)
            {
                ETag = "*"
            });

            return RedirectToAction(nameof(Index));
        }
    }
}
