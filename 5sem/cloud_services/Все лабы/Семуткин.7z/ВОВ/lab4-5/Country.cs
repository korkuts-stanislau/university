﻿using Microsoft.Azure.Cosmos.Table;

namespace CosmosTableSamples.Model
{
    public class Country : TableEntity
    {
        public string CountryName { get; set; }

        public Country(int id)
        {
            PartitionKey = "1";
            RowKey = id.ToString();
        }

        public Country() { }
    }
}
