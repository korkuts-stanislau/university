﻿using CosmosTableSamples.Model;
using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CosmosTableSamples
{
    public class EntityOperations
    {
        // таблица MusicCatalog
        public static async Task<MusicCatalog> GetMusicCatalogAsync(CloudTable table, int id)
        {
            string partitionKey = "1";
            try
            {
                TableOperation retrieveOperation = TableOperation.Retrieve<MusicCatalog>(partitionKey, id.ToString());
                TableResult result = await table.ExecuteAsync(retrieveOperation);
                MusicCatalog catalog = result.Result as MusicCatalog;
                return catalog;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public List<MusicCatalog> GetMusicCatalogs(CloudTable table)
        {
            TableQuery<MusicCatalog> catalogsQuery = new TableQuery<MusicCatalog>();
            List<MusicCatalog> catalogs = new List<MusicCatalog>();
            foreach (MusicCatalog catalog in table.ExecuteQuery(catalogsQuery))
            {
                catalogs.Add(catalog);
            }
            return catalogs;
        }

        public async Task<MusicCatalog> InsertOrMergeMusicCatalogAsync(CloudTable table, MusicCatalog catalog)
        {
            try
            {
                TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(catalog);
                TableResult result = await table.ExecuteAsync(insertOrMergeOperation);
                MusicCatalog insertedCatalog = result.Result as MusicCatalog;

                return insertedCatalog;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task<MusicCatalog> DeleteMusicCatalogAsync(CloudTable table, MusicCatalog catalog)
        {
            try
            {
                TableOperation deleteOperation = TableOperation.Delete(catalog);
                TableResult result = await table.ExecuteAsync(deleteOperation);
                MusicCatalog deletedCatalog = result.Result as MusicCatalog;

                return deletedCatalog;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        // таблица Genre
        public static async Task<Genre> GetGenreAsync(CloudTable table, int id)
        {
            string partitionKey = "1";
            try
            {
                TableOperation retrieveOperation = TableOperation.Retrieve<Genre>(partitionKey, id.ToString());
                TableResult result = await table.ExecuteAsync(retrieveOperation);
                Genre genre = result.Result as Genre;
                return genre;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public List<Genre> GetGenres(CloudTable table)
        {
            TableQuery<Genre> genresQuery = new TableQuery<Genre>();
            List<Genre> genres = new List<Genre>();
            foreach (Genre genre in table.ExecuteQuery(genresQuery))
            {
                genres.Add(genre);
            }
            return genres;
        }

        public async Task<Genre> InsertOrMergeGenreAsync(CloudTable table, Genre genre)
        {
            try
            {
                TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(genre);
                TableResult result = await table.ExecuteAsync(insertOrMergeOperation);
                Genre insertedGenre = result.Result as Genre;

                return insertedGenre;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task<Genre> DeleteGenreAsync(CloudTable table, Genre genre)
        {
            try
            {
                TableOperation deleteOperation = TableOperation.Delete(genre);
                TableResult result = await table.ExecuteAsync(deleteOperation);
                Genre deletedGenre = result.Result as Genre;

                return deletedGenre;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task CascadeDeleteGenre(CloudTable musicCatalogsTable, CloudTable genresTable, Genre genre)
        {
            try
            {
                var catalogs = GetMusicCatalogs(musicCatalogsTable);
                foreach (MusicCatalog catalog in catalogs)
                {
                    if (catalog.GenreID == int.Parse(genre.RowKey))
                    {
                        await DeleteMusicCatalogAsync(musicCatalogsTable, catalog);
                    }
                }
                await DeleteGenreAsync(genresTable, genre);
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        // таблица Country
        public static async Task<Country> GetCountryAsync(CloudTable table, int id)
        {
            string partitionKey = "1";
            try
            {
                TableOperation retrieveOperation = TableOperation.Retrieve<Country>(partitionKey, id.ToString());
                TableResult result = await table.ExecuteAsync(retrieveOperation);
                Country country = result.Result as Country;
                return country;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public List<Country> GetCountries(CloudTable table)
        {
            TableQuery<Country> countriesQuery = new TableQuery<Country>();
            List<Country> countries = new List<Country>();
            foreach (Country country in table.ExecuteQuery(countriesQuery))
            {
                countries.Add(country);
            }
            return countries;
        }

        public async Task<Country> InsertOrMergeCountryAsync(CloudTable table, Country country)
        {
            try
            {
                TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(country);
                TableResult result = await table.ExecuteAsync(insertOrMergeOperation);
                Country insertedCountry = result.Result as Country;

                return insertedCountry;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task<Country> DeleteCountryAsync(CloudTable table, Country country)
        {
            try
            {
                TableOperation deleteOperation = TableOperation.Delete(country);
                TableResult result = await table.ExecuteAsync(deleteOperation);
                Country deletedCountry = result.Result as Country;

                return deletedCountry;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task CascadeDeleteCountry(CloudTable musicCatalogsTable, CloudTable countriesTable, Country country)
        {
            try
            {
                var catalogs = GetMusicCatalogs(musicCatalogsTable);
                foreach (MusicCatalog catalog in catalogs)
                {
                    if (catalog.CountryID == int.Parse(country.RowKey))
                    {
                        await DeleteMusicCatalogAsync(musicCatalogsTable, catalog);
                    }
                }
                await DeleteCountryAsync(countriesTable, country);
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        // таблица Styles
        public static async Task<Style> GetStyleAsync(CloudTable table, int id)
        {
            string partitionKey = "1";
            try
            {
                TableOperation retrieveOperation = TableOperation.Retrieve<Style>(partitionKey, id.ToString());
                TableResult result = await table.ExecuteAsync(retrieveOperation);
                Style style = result.Result as Style;
                return style;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public List<Style> GetStyles(CloudTable table)
        {
            TableQuery<Style> stylesQuery = new TableQuery<Style>();
            List<Style> styles = new List<Style>();
            foreach (Style style in table.ExecuteQuery(stylesQuery))
            {
                styles.Add(style);
            }
            return styles;
        }

        public async Task<Style> InsertOrMergeStyleAsync(CloudTable table, Style style)
        {
            try
            {
                TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(style);
                TableResult result = await table.ExecuteAsync(insertOrMergeOperation);
                Style insertedStyle = result.Result as Style;

                return insertedStyle;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task<Style> DeleteStyleAsync(CloudTable table, Style style)
        {
            try
            {
                TableOperation deleteOperation = TableOperation.Delete(style);
                TableResult result = await table.ExecuteAsync(deleteOperation);
                Style deletedStyle = result.Result as Style;

                return deletedStyle;
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }

        public async Task CascadeDeleteStyle(CloudTable musicCatalogsTable, CloudTable stylesTable, Style style)
        {
            try
            {
                var catalogs = GetMusicCatalogs(musicCatalogsTable);
                foreach (MusicCatalog catalog in catalogs)
                {
                    if (catalog.StyleID == int.Parse(style.RowKey))
                    {
                        await DeleteMusicCatalogAsync(musicCatalogsTable, catalog);
                    }
                }
                await DeleteStyleAsync(stylesTable, style);
            }
            catch (StorageException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
                throw;
            }
        }
    }
}
