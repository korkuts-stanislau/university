﻿using CosmosTableSamples;
using CosmosTableSamples.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.Controllers
{
    public class StyleController : Controller
    {
        private readonly StorageOperations _so;
        private readonly EntityOperations _eo;

        public StyleController()
        {
            _so = new StorageOperations();
            _eo = new EntityOperations();
        }

        public async Task<ActionResult> Index()
        {
            var stylesTable = await _so.CreateTableAsync("Styles");
            var styles = _eo.GetStyles(stylesTable);

            return View(styles);
        }

        public async Task<ActionResult> Create()
        {
            var stylesTable = await _so.CreateTableAsync("Styles");
            var styles = _eo.GetStyles(stylesTable);

            return View(styles);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(string styleName)
        {
            try
            {
                var stylesTable = await _so.CreateTableAsync("Styles");
                int maxID = _eo.GetStyles(stylesTable)
                    .Select(s => int.Parse(s.RowKey)).Max();

                Style style = new Style(maxID + 1)
                {
                    StyleName = styleName
                };
                await _eo.InsertOrMergeStyleAsync(stylesTable, style);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                var stylesTable = await _so.CreateTableAsync("Styles");
                var styles = _eo.GetStyles(stylesTable);

                return View(styles);
            }
        }

        public async Task<ActionResult> Edit(int id)
        {
            var stylesTable = await _so.CreateTableAsync("Styles");
            var style = _eo.GetStyles(stylesTable)
                .FirstOrDefault(s => int.Parse(s.RowKey) == id);
            ViewBag.Style = style;

            return View(style);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, string styleName)
        {
            try
            {
                Style style = new Style(id)
                {
                    StyleName = styleName
                };

                var stylesTable = await _so.CreateTableAsync("Styles");
                await _eo.InsertOrMergeStyleAsync(stylesTable, style);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                var stylesTable = await _so.CreateTableAsync("Styles");
                var style = _eo.GetStyles(stylesTable)
                    .FirstOrDefault(s => int.Parse(s.RowKey) == id);
                ViewBag.Style = style;

                return View(style);
            }
        }

        public async Task<ActionResult> Delete(int id)
        {
            var catalogTable = await _so.CreateTableAsync("MusicCatalog");
            var stylesTable = await _so.CreateTableAsync("Styles");

            await _eo.CascadeDeleteStyle(catalogTable, stylesTable, new Style(id)
            {
                ETag = "*"
            });

            return RedirectToAction(nameof(Index));
        }
    }
}
