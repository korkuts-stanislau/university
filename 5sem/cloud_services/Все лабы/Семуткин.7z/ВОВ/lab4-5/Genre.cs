﻿using Microsoft.Azure.Cosmos.Table;

namespace CosmosTableSamples.Model
{
    public class Genre : TableEntity
    {
        public string GenreName { get; set; }

        public Genre(int id)
        {
            PartitionKey = "1";
            RowKey = id.ToString();
        }

        public Genre() { }
    }
}
