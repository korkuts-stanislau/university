﻿using CosmosTableSamples;
using CosmosTableSamples.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.ViewModels;

namespace WebApplication.Controllers
{
    public class MusicCatalogController : Controller
    {
        private readonly StorageOperations _so;
        private readonly EntityOperations _eo;

        public MusicCatalogController()
        {
            _so = new StorageOperations();
            _eo = new EntityOperations();
        }

        public async Task<ActionResult> Index()
        {
            var catalogsTable = await _so.CreateTableAsync("MusicCatalog");
            var countriesTable = await _so.CreateTableAsync("Countries");
            var genresTable = await _so.CreateTableAsync("Genres");
            var stylesTable = await _so.CreateTableAsync("Styles");

            var catalogs = _eo.GetMusicCatalogs(catalogsTable);
            var countries = _eo.GetCountries(countriesTable);
            var genres = _eo.GetGenres(genresTable);
            var styles = _eo.GetStyles(stylesTable);

            IndexMusicCatalog model = new IndexMusicCatalog
            {
                MusicCatalogs = catalogs,
                Countries = new Dictionary<string, string>(countries
                    .Select(c => new KeyValuePair<string, string>(c.RowKey, c.CountryName))
                    .ToList()),
                Genres = new Dictionary<string, string>(genres
                    .Select(g => new KeyValuePair<string, string>(g.RowKey, g.GenreName))
                    .ToList()),
                Styles = new Dictionary<string, string>(styles
                    .Select(s => new KeyValuePair<string, string>(s.RowKey, s.StyleName))
                    .ToList())
            };

            return View(model);
        }

        public async Task<ActionResult> Create()
        {
            var countriesTable = await _so.CreateTableAsync("Countries");
            var genresTable = await _so.CreateTableAsync("Genres");
            var stylesTable = await _so.CreateTableAsync("Styles");

            var countries = _eo.GetCountries(countriesTable);
            var genres = _eo.GetGenres(genresTable);
            var styles = _eo.GetStyles(stylesTable);

            CreateMusicCatalog model = new CreateMusicCatalog
            {
                Countries = new SelectList(countries, "RowKey", "CountryName"),
                Genres = new SelectList(genres, "RowKey", "GenreName"),
                Styles = new SelectList(styles, "RowKey", "StyleName")
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(string musicName, string format,
            int? countryId, DateTime releaseDate, int? genreId, int? styleId, string description)
        {
            try
            {
                var catalogsTable = await _so.CreateTableAsync("MusicCatalog");
                int maxID = _eo.GetMusicCatalogs(catalogsTable)
                    .Select(c => int.Parse(c.RowKey)).Max();

                MusicCatalog catalog = new MusicCatalog(maxID + 1)
                {
                    MusicName = musicName,
                    Format = format,
                    CountryID = countryId ?? 1,
                    ReleaseDate = releaseDate,
                    GenreID = genreId ?? 1,
                    StyleID = styleId ?? 1,
                    Description = description
                };
                await _eo.InsertOrMergeMusicCatalogAsync(catalogsTable, catalog);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                var countriesTable = await _so.CreateTableAsync("Countries");
                var genresTable = await _so.CreateTableAsync("Genres");
                var stylesTable = await _so.CreateTableAsync("Styles");

                var countries = _eo.GetCountries(countriesTable);
                var genres = _eo.GetGenres(genresTable);
                var styles = _eo.GetStyles(stylesTable);

                CreateMusicCatalog model = new CreateMusicCatalog
                {
                    Countries = new SelectList(countries, "RowKey", "CountryName"),
                    Genres = new SelectList(genres, "RowKey", "GenreName"),
                    Styles = new SelectList(styles, "RowKey", "StyleName")
                };

                return View(model);
            }
        }

        public async Task<ActionResult> Edit(int id)
        {
            var countriesTable = await _so.CreateTableAsync("Countries");
            var genresTable = await _so.CreateTableAsync("Genres");
            var stylesTable = await _so.CreateTableAsync("Styles");
            var catalogsTable = await _so.CreateTableAsync("MusicCatalog");

            var countries = _eo.GetCountries(countriesTable);
            var genres = _eo.GetGenres(genresTable);
            var styles = _eo.GetStyles(stylesTable);
            var catalog = _eo.GetMusicCatalogs(catalogsTable)
                .FirstOrDefault(c => int.Parse(c.RowKey) == id);

            CreateMusicCatalog model = new CreateMusicCatalog
            {
                Countries = new SelectList(countries, "RowKey", "CountryName", catalog.CountryID.ToString()),
                Genres = new SelectList(genres, "RowKey", "GenreName", catalog.GenreID.ToString()),
                Styles = new SelectList(styles, "RowKey", "StyleName", catalog.StyleID.ToString())
            };
            ViewBag.MusicCatalog = catalog;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, string musicName, string format,
            int? countryId, DateTime releaseDate, int? genreId, int? styleId, string description)
        {
            try
            {
                MusicCatalog catalog = new MusicCatalog(id)
                {
                    MusicName = musicName,
                    Format = format,
                    CountryID = countryId ?? 1,
                    ReleaseDate = releaseDate,
                    GenreID = genreId ?? 1,
                    StyleID = styleId ?? 1,
                    Description = description
                };
                var catalogsTable = await _so.CreateTableAsync("MusicCatalog");
                await _eo.InsertOrMergeMusicCatalogAsync(catalogsTable, catalog);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                var countriesTable = await _so.CreateTableAsync("Countries");
                var genresTable = await _so.CreateTableAsync("Genres");
                var stylesTable = await _so.CreateTableAsync("Styles");
                var catalogsTable = await _so.CreateTableAsync("MusicCatalog");

                var countries = _eo.GetCountries(countriesTable);
                var genres = _eo.GetGenres(genresTable);
                var styles = _eo.GetStyles(stylesTable);
                var catalog = _eo.GetMusicCatalogs(catalogsTable)
                    .FirstOrDefault(c => int.Parse(c.RowKey) == id);

                CreateMusicCatalog model = new CreateMusicCatalog
                {
                    Countries = new SelectList(countries, "RowKey", "CountryName", catalog.CountryID.ToString()),
                    Genres = new SelectList(genres, "RowKey", "GenreName", catalog.GenreID.ToString()),
                    Styles = new SelectList(styles, "RowKey", "StyleName", catalog.StyleID.ToString())
                };
                ViewBag.MusicCatalog = catalog;

                return View(model);
            }
        }

        public async Task<ActionResult> Delete(int id)
        {
            var catalogsTable = await _so.CreateTableAsync("MusicCatalog");
            await _eo.DeleteMusicCatalogAsync(catalogsTable, new MusicCatalog(id)
            {
                ETag = "*"
            });

            return RedirectToAction(nameof(Index));
        }
    }
}
